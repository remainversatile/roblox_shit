@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo Run Setup.bat once before launching the macro.
    pause
    exit /b 1
)
start "" ".venv\Scripts\pythonw.exe" "src\main.py"
