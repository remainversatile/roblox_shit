import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np

sys.path.insert(0, str(Path(__file__).parent / "src"))
from adventure import Adventure, parse_act
from ocr import Line
from popup_scanner import PopupScanner


class ControlTests(unittest.TestCase):
    def make(self, target=4):
        self.text = "ACT 4/10"
        self.clicks = []
        reader = SimpleNamespace(text=lambda _: self.text, read=lambda _: [Line("RETURN HOME", 5, 100, 100, 30)])
        r = SimpleNamespace(cfg={"adventure_mode": True, "world_index": target}, reader=reader,
                            aborted=lambda: False, _focus=lambda: None,
                            _click=lambda *args: self.clicks.append(args), status=lambda _: None)
        return Adventure(r)

    def step(self, a):
        a.next_scan = 0
        return a.step(SimpleNamespace(w=1920, h=1080), np.zeros((1080,1920,3), dtype=np.uint8))

    def test_parser(self):
        for text, expected in [("ACT 4/10",4),("ACT I0/10",10),("ACT 11/10",None),("EN 4/10",None),("",None)]:
            self.assertEqual(parse_act(text), expected)

    def test_transition_requires_two_readings(self):
        a=self.make();self.assertFalse(self.step(a))
        self.text="ACT 5/10";self.assertTrue(self.step(a));self.assertFalse(self.clicks)
        self.assertTrue(self.step(a));self.assertTrue(a.returning);self.assertEqual(len(self.clicks),1)

    def test_missing_reading_does_not_return(self):
        a=self.make();self.step(a);self.text="";self.step(a);self.step(a)
        self.assertFalse(a.returning);self.assertFalse(self.clicks)

    def test_noise_resets_confirmation(self):
        a=self.make();self.step(a);self.text="ACT 5/10";self.step(a)
        self.text="";self.step(a);self.text="ACT 5/10";self.step(a)
        self.assertFalse(self.clicks)

    def test_disabled(self):
        a=self.make();a.r.cfg["adventure_mode"]=False
        self.assertFalse(self.step(a));self.assertFalse(self.clicks)

    def test_stop_prevents_click(self):
        a=self.make();a.r.aborted=lambda: True;a.click(SimpleNamespace(),10,10)
        self.assertFalse(self.clicks)

    def test_world_search_right_until_four(self):
        a = self.make()
        a.nightmare = True
        a.r.reader.read = lambda _: [Line("START RUN", 1100, 700, 150, 40), Line("START AT", 800, 700, 80, 15)]
        for name in ("SUNMEADOW WILDS", "WORLD TWO", "WORLD THREE", "MOONSTONE RISE"):
            answers = iter(("", "ELITE PATROLS", name))
            a.r.reader.text = lambda _: next(answers)
            self.step(a)
        self.assertEqual([click[1:] for click in self.clicks[:3]], [(1062, 772)] * 3)
        self.assertEqual(self.clicks[3][1:], (1175, 720))
        self.assertTrue(a.running)

    def test_world_four_already_selected(self):
        a = self.make(); a.nightmare = True
        a.r.reader.read = lambda _: [Line("START RUN", 1100, 700, 150, 40), Line("START AT", 800, 700, 80, 15)]
        answers = iter(("", "ELITE PATROLS", "MOONSTONE RISE"))
        a.r.reader.text = lambda _: next(answers)
        self.step(a)
        self.assertEqual(len(self.clicks), 1)
        self.assertEqual(self.clicks[0][1:], (1175, 720))

    def test_continue_button_and_settle(self):
        a = self.make(); scanner = PopupScanner(a.r)
        frame = np.zeros((1080,1920,3), dtype=np.uint8)
        frame[760:800,850:1060] = (120,196,231)
        self.text = "CONTINUE"
        rect = SimpleNamespace(w=1920,h=1080)
        self.assertTrue(scanner.step(rect, frame))
        self.assertEqual(self.clicks[0][1:], (955,780))
        self.assertTrue(scanner.step(rect, frame))
        self.assertEqual(len(self.clicks), 1)
        scanner.settle_until = scanner.next_scan = 0
        self.assertTrue(scanner.step(rect, frame))
        self.assertEqual(len(self.clicks), 2)

    def test_other_gold_button_not_clicked(self):
        a = self.make(); scanner = PopupScanner(a.r)
        frame = np.zeros((1080,1920,3), dtype=np.uint8)
        frame[760:800,850:1060] = (120,196,231)
        self.text = "BUY"
        self.assertFalse(scanner.step(SimpleNamespace(w=1920,h=1080), frame))
        self.assertFalse(self.clicks)


if __name__ == "__main__":
    unittest.main()
