"""Local OCR recovery through Roblox's registered game launch protocol."""
import os
import re
import time

from adventure import normalize
from screens import DEFAULT_AREAS, crop

GAME_URI = "roblox://placeId=126256942507957"


def disconnected(text):
    text = normalize(text)
    context = any(word in text for word in (
        "DISCONNECTED", "CONNECTION", "NETWORK", "INTERNET", "ROBLOX HAS CRASHED",
        "UNEXPECTED ERROR", "ERROR CODE", "FAILED TO CONNECT", "RECONNECT"))
    button = any(re.search(r"\b" + word + r"\b", text) for word in ("RECONNECT", "RETRY", "OK", "LEAVE", "QUIT"))
    return context and button


def slot_enter(lines, slot, width, height):
    """Use the selected slot's column, never another slot's Enter/Unlock/Edit."""
    headers = []
    for line in lines:
        found = re.search(r"\bSLOT\s*0*([1-6])\b", normalize(line.text))
        if found:
            headers.append((int(found[1]), line))
    anchor = next((line for number, line in headers if number == slot), None)
    if anchor is None:
        return None
    right = min([line.x for _, line in headers if line.x > anchor.x and abs(line.y-anchor.y) < height*.08] or [anchor.x + width*.18])
    entries = [line for line in lines if normalize(line.text).startswith("ENTER")
               and anchor.x <= line.cx < right and anchor.y < line.cy < anchor.y+height*.30]
    return entries[0] if len(entries) == 1 else None


class Recovery:
    def __init__(self, runner, launcher=None):
        self.r = runner
        self.launcher = launcher or os.startfile
        self.next_scan = 0.0
        self.next_launch = 0.0
        self.missing_since = None
        self.active = False
        self.started = 0.0
        self.attempts = 0
        self.error_reads = 0

    def launch(self, now):
        if self.r.aborted() or now < self.next_launch:
            return
        self.attempts += 1
        self.active = True
        self.started = now
        self.next_launch = now + min(300, 90 * self.attempts)
        self.r.status("Reopening Pixel Lineage; waiting for Character Select.")
        try:
            self.launcher(GAME_URI)
        except OSError as exc:
            self.r.status(f"Roblox could not launch: {exc}. Check the Roblox installation.")

    def missing(self):
        if not self.r.cfg.get("auto_reconnect", True):
            return False
        now = time.perf_counter()
        if self.missing_since is None:
            self.missing_since = now
        if now-self.missing_since >= 5:
            self.launch(now)
        return True

    def step(self, rect, frame, battle=False):
        self.missing_since = None
        if not self.r.cfg.get("auto_reconnect", True):
            return False
        now = time.perf_counter()
        if now < self.next_scan:
            return self.active
        self.next_scan = now + 1.2
        img, _, _ = crop(frame, self.r.cfg.get("reconnect_area") or DEFAULT_AREAS["reconnect_area"])
        central_text = self.r.reader.text(img)
        error = disconnected(central_text)
        self.error_reads = self.error_reads+1 if error else 0
        if error:
            if self.error_reads >= 2:
                self.launch(now)
            return True
        if not self.active and "YOUR CHARACTERS" not in normalize(central_text):
            if battle:
                return False
            title, _, _ = crop(frame, {"x": .025, "y": .72, "w": .24, "h": .09})
            if "CHARACTER SELECT" not in normalize(self.r.reader.text(title)):
                return False
        lines = self.r.reader.read(frame)
        def find(label):
            return next((line for line in lines if label.replace(" ", "") in normalize(line.text).replace(" ", "")), None)
        if find("SET OUT"):
            if self.active:
                self.r.adventure.running = self.r.adventure.returning = False
                self.r.adventure.reset_lobby()
                self.r.adventure.candidate = None
                self.r.adventure.hits = 0
            self.active = False
            self.attempts = 0
            self.next_launch = 0
            return False
        character = find("CHARACTER SELECT")
        slots = find("YOUR CHARACTERS") or "YOUR CHARACTERS" in normalize(central_text)
        if character or slots:
            if not self.active:
                self.started = now
            self.active = True
            slot = max(1, min(6, int(self.r.cfg.get("character_slot", 1))))
            target = character if character else slot_enter(lines, slot, rect.w, rect.h)
            if target and not self.r.aborted():
                self.r._focus()
                self.r._click(rect, target.cx, target.cy)
                self.next_scan = now + 2.0
                self.r.status("Opening Character Select." if character else f"Entering character slot {slot}.")
            else:
                self.r.status(f"Slot {slot}: waiting for a visible Enter button. Locked/empty slots are not selected.")
            return True
        if self.active:
            self.r.status("Waiting for Roblox to load the character or castle...")
            if now-self.started > 180:
                self.launch(now)
            return True
        return False
