import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np

sys.path.insert(0, str(Path(__file__).parent / "src"))
from recovery import Recovery, disconnected, slot_enter
from popup_scanner import PopupScanner
from ocr import Line


class RecoveryTests(unittest.TestCase):
    def runner(self):
        self.clicks = []
        self.launches = []
        self.text = ""
        return SimpleNamespace(cfg={},reader=SimpleNamespace(text=lambda _:self.text,read=lambda _:[]),
            aborted=lambda:False,status=lambda _:None,_focus=lambda:None,
            _click=lambda rect,x,y:self.clicks.append((x,y)))

    def test_error_context_required(self):
        for message in ("Disconnected Error code 277 Reconnect", "Internet connection lost Retry", "Roblox has crashed OK"):
            self.assertTrue(disconnected(message))
        for message in ("OK", "Retry", "Play Again", "Connection", "TO BATTLE"):
            self.assertFalse(disconnected(message))

    def test_missing_client_delay_cooldown_and_stop(self):
        r=self.runner(); recovery=Recovery(r,self.launches.append)
        with patch('recovery.time.perf_counter',return_value=10): recovery.missing()
        with patch('recovery.time.perf_counter',return_value=14): recovery.missing()
        self.assertEqual(self.launches,[])
        with patch('recovery.time.perf_counter',return_value=16): recovery.missing()
        with patch('recovery.time.perf_counter',return_value=20): recovery.missing()
        self.assertEqual(len(self.launches),1)
        r.aborted=lambda:True
        recovery.launch(500)
        self.assertEqual(len(self.launches),1)

    def test_disabled_reconnect(self):
        r=self.runner();r.cfg['auto_reconnect']=False
        recovery=Recovery(r,self.launches.append)
        self.assertFalse(recovery.missing())

    def test_correct_slot_not_unlock(self):
        lines=[Line('SLOT 01',640,440,60,12),Line('ENTER LEVEL 50',677,675,120,12),
               Line('SLOT 02',976,440,60,12),Line('UNLOCK R100',1000,675,120,12)]
        self.assertEqual(slot_enter(lines,1,1920,1080),lines[1])
        self.assertIsNone(slot_enter(lines,2,1920,1080))
        self.assertIsNone(slot_enter(lines,3,1920,1080))

    def test_to_battle_waits_five_seconds(self):
        r=self.runner();self.text='TO BATTLE!';p=PopupScanner(r)
        frame=np.zeros((1080,1920,3),dtype=np.uint8);frame[475:515,1280:1490]=(120,196,231)
        rect=SimpleNamespace(w=1920,h=1080)
        with patch('popup_scanner.time.perf_counter',return_value=10):self.assertFalse(p.step(rect,frame))
        with patch('popup_scanner.time.perf_counter',return_value=14.9):self.assertFalse(p.step(rect,frame))
        with patch('popup_scanner.time.perf_counter',return_value=15.6):self.assertTrue(p.step(rect,frame))
        self.assertEqual(self.clicks,[(1385,495)])

    def test_disappearing_button_resets_wait(self):
        r=self.runner();self.text='TO BATTLE';p=PopupScanner(r)
        frame=np.zeros((1080,1920,3),dtype=np.uint8);frame[475:515,1280:1490]=(120,196,231)
        rect=SimpleNamespace(w=1920,h=1080)
        with patch('popup_scanner.time.perf_counter',return_value=10):p.step(rect,frame)
        with patch('popup_scanner.time.perf_counter',return_value=13):p.step(rect,np.zeros_like(frame))
        with patch('popup_scanner.time.perf_counter',return_value=16):self.assertFalse(p.step(rect,frame))
        self.assertEqual(self.clicks,[])


if __name__=='__main__': unittest.main()
